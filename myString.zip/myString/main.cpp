#include <iostream>
#include <string>
#include "myString.h"

using namespace std;

int main()
{
    string str1, str2;
    int userChoice;
    char c;

    cout << myName() << endl;

    do{
      cout << "--------------------------------------------------------\n";
      cout << "Enter the number of the function you would like to test:\n";
      cout << "\t1. countChar()\n";
      cout << "\t2. countVowels()\n";
      cout << "\t3. countNumbers()\n";
      cout << "\t4. longestWord()\n";
      cout << "\t5. capitalizeWords()\n";
      cout << "\t6. changeCase()\n";
      cout << "\t7. reverseString()\n";
      cout << "\t8. isPalindrome()\n";
      cout << "\t9. isSubstring()\n";
      cout << "\t0. Exit Program\n";

      cin >> userChoice;
      cin.ignore(); // this is needed to mix cin with getline

      switch(userChoice){
         case 0:
            return 0;
         case 1:
            cout << "countChar() #1: " << (countChar("aoeuaoeuaoeuaoeu", 'a') == 4) << endl;
            cout << "countChar() #2: " << (countChar("aoeuaoeuaoeuaoeu", 'A') == 0) << endl;
            break;
         case 2:
            cout << "countVowels() #1: " << (countVowels("aoeuaoeuaoeuaoeu") == 16) << endl;
            cout << "countVowels() #2: " << (countVowels("AYAYhhttnnao") == 6) << endl;
            break;
         case 3:
            cout << "countNumbers() #1: " << (countNumbers("a1b2  c3d!@4f0") == 5) << endl;
            break;
         case 4:
            cout << "longestWord() #1:" << (longestWord("aeouaua a aoeuuaTT_12") == 11) << endl;
            break;
         case 5:
            // TODO
            cout << "TODO capitalizeWords\n";
            break;
         case 6:
            // TODO
            cout << "TODO changeCase\n";
            break;
         case 7:
            // TODO
            cout << "TODO reverseString()\n";
            break;
         case 8:
            // TODO
            cout << "TODO isPalindrome()\n";
            break;
         case 9:
            // TODO
            cout << "TODO isSubstring()\n";
            break;
         default:
            cout << "Not a valid option.\n";
      }

    }while(userChoice != 0);



}
