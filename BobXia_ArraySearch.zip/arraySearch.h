#ifndef ARRAYSEARCH_H_INCLUDED
#define ARRAYSEARCH_H_INCLUDED

bool search_unsorted(int value, int arr[], int length);
// Returns true if value exists in arr, false otherwise.
// Time complexity: O(n)

bool search_sorted(int value, int arr[], int length);
// Returns true if value exists in a sorted arr, false otherwise.
// Time complexity: O(log n)

bool test_search_unsorted();
// Runs hard-coded tests for search_unsorted()
// Returns true only if all tests pass

bool test_search_sorted();
// Runs hard-coded tests for search_sorted()
// Returns true only if all tests pass

#endif // ARRAYSEARCH_H_INCLUDED
