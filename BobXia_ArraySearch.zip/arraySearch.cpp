/* ================================================================================================
Name: Bob Xia
Date: 2026-03-30
Project: Array Search C++
=================================================================================================*/

#include <iostream>
#include "arraySearch.h"

using namespace std;

/* --------------------------------------------------------------------------------------------- */
// Local helper function for printing test results.

void print_test_result(const char* functionName, int testNumber, bool actual, bool expected) {
    cout << functionName << " Test #" << testNumber << ": ";
    if (actual == expected) {
        cout << "PASS";
    } else {
        cout << "FAIL";
    }
    cout << " | Expected: " << expected << " | Got: " << actual << endl;
}

/* --------------------------------------------------------------------------------------------- */

bool search_unsorted(int value, int arr[], int length) {
    for (int i = 0; i < length; i++) {
        if (arr[i] == value) {
            return true;
        }
    }
    return false;
}

/* --------------------------------------------------------------------------------------------- */

bool search_sorted(int value, int arr[], int length) {
    int left = 0;
    int right = length - 1;

    while (left <= right) {
        int mid = left + (right - left) / 2;

        if (arr[mid] == value) {
            return true;
        } else if (value < arr[mid]) {
            right = mid - 1;
        } else {
            left = mid + 1;
        }
    }

    return false;
}

/* --------------------------------------------------------------------------------------------- */

bool test_search_unsorted() {
    cout << "Testing search_unsorted()" << endl;

    bool allPassed = true;

    int arr1[] = {4, 9, 2, 7, 1, 5};
    bool result1 = search_unsorted(7, arr1, 6);
    bool expected1 = true;
    print_test_result("search_unsorted", 1, result1, expected1);
    allPassed = allPassed && (result1 == expected1);

    int arr2[] = {4, 9, 2, 7, 1, 5};
    bool result2 = search_unsorted(8, arr2, 6);
    bool expected2 = false;
    print_test_result("search_unsorted", 2, result2, expected2);
    allPassed = allPassed && (result2 == expected2);

    int arr3[] = {10};
    bool result3 = search_unsorted(10, arr3, 1);
    bool expected3 = true;
    print_test_result("search_unsorted", 3, result3, expected3);
    allPassed = allPassed && (result3 == expected3);

    int arr4[] = {10};
    bool result4 = search_unsorted(3, arr4, 1);
    bool expected4 = false;
    print_test_result("search_unsorted", 4, result4, expected4);
    allPassed = allPassed && (result4 == expected4);

    int arr5[] = {-5, -2, 0, 3, 8};
    bool result5 = search_unsorted(-2, arr5, 5);
    bool expected5 = true;
    print_test_result("search_unsorted", 5, result5, expected5);
    allPassed = allPassed && (result5 == expected5);

    int arr6[] = {6, 6, 6, 6, 6};
    bool result6 = search_unsorted(6, arr6, 5);
    bool expected6 = true;
    print_test_result("search_unsorted", 6, result6, expected6);
    allPassed = allPassed && (result6 == expected6);

    int arr7[] = {6, 6, 6, 6, 6};
    bool result7 = search_unsorted(4, arr7, 5);
    bool expected7 = false;
    print_test_result("search_unsorted", 7, result7, expected7);
    allPassed = allPassed && (result7 == expected7);

    cout << "search_unsorted() overall: " << (allPassed ? "PASS" : "FAIL") << endl;
    return allPassed;
}

/* --------------------------------------------------------------------------------------------- */

bool test_search_sorted() {
    cout << "Testing search_sorted()" << endl;

    bool allPassed = true;

    int arr1[] = {1, 3, 5, 7, 9, 11, 13};
    bool result1 = search_sorted(7, arr1, 7);
    bool expected1 = true;
    print_test_result("search_sorted", 1, result1, expected1);
    allPassed = allPassed && (result1 == expected1);

    int arr2[] = {1, 3, 5, 7, 9, 11, 13};
    bool result2 = search_sorted(2, arr2, 7);
    bool expected2 = false;
    print_test_result("search_sorted", 2, result2, expected2);
    allPassed = allPassed && (result2 == expected2);

    int arr3[] = {2, 4, 6, 8, 10};
    bool result3 = search_sorted(2, arr3, 5);
    bool expected3 = true;
    print_test_result("search_sorted", 3, result3, expected3);
    allPassed = allPassed && (result3 == expected3);

    int arr4[] = {2, 4, 6, 8, 10};
    bool result4 = search_sorted(10, arr4, 5);
    bool expected4 = true;
    print_test_result("search_sorted", 4, result4, expected4);
    allPassed = allPassed && (result4 == expected4);

    int arr5[] = {-10, -3, 0, 4, 12, 18};
    bool result5 = search_sorted(-10, arr5, 6);
    bool expected5 = true;
    print_test_result("search_sorted", 5, result5, expected5);
    allPassed = allPassed && (result5 == expected5);

    int arr6[] = {-10, -3, 0, 4, 12, 18};
    bool result6 = search_sorted(18, arr6, 6);
    bool expected6 = true;
    print_test_result("search_sorted", 6, result6, expected6);
    allPassed = allPassed && (result6 == expected6);

    int arr7[] = {5};
    bool result7 = search_sorted(1, arr7, 1);
    bool expected7 = false;
    print_test_result("search_sorted", 7, result7, expected7);
    allPassed = allPassed && (result7 == expected7);

    int arr8[] = {1, 2, 2, 2, 3, 4, 5};
    bool result8 = search_sorted(2, arr8, 7);
    bool expected8 = true;
    print_test_result("search_sorted", 8, result8, expected8);
    allPassed = allPassed && (result8 == expected8);

    cout << "search_sorted() overall: " << (allPassed ? "PASS" : "FAIL") << endl;
    return allPassed;
}

/* --------------------------------------------------------------------------------------------- */
