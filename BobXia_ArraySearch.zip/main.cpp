#include <iostream>
#include "arraySearch.h"

using namespace std;

int main() {
    cout << "Bob Xia" << endl;
    cout << "========================================" << endl;
    cout << "Array Search C++ Project" << endl;
    cout << "========================================" << endl;

    bool unsortedPassed = test_search_unsorted();
    cout << endl;

    bool sortedPassed = test_search_sorted();
    cout << endl;

    cout << "========================================" << endl;
    if (unsortedPassed && sortedPassed) {
        cout << "All tests passed!" << endl;
    } else {
        cout << "Some tests failed." << endl;
    }
    cout << "========================================" << endl;

    return 0;
}
