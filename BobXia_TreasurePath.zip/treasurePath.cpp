#include <iostream>
#include <climits>
#include "treasurePath.h"

using namespace std;

// ------------------------------------------------------------
// Provided test arrays from the assignment
// The optimal path always follows 7s, so expected answer is
// 7 * number of rows.
// ------------------------------------------------------------
extern const int TA1_ROWS = 2;
int ta1[TA1_ROWS][COLS] = {
    {7, 3, 4, 1, 2},
    {4, 7, 2, 0, 0}
};

extern const int TA2_ROWS = 4;
int ta2[TA2_ROWS][COLS] = {
    {2, 7, 4, 0, 4},
    {7, 3, 2, 0, 5},
    {3, 7, 4, 5, 7},
    {2, 0, 7, 4, 5}
};

extern const int TA3_ROWS = 5;
int ta3[TA3_ROWS][COLS] = {
    {7, 3, 4, 5, 6},
    {2, 7, 5, 0, 6},
    {3, 0, 7, 5, 6},
    {1, 3, 4, 7, 6},
    {2, 3, 4, 5, 7}
};

extern const int TA4_ROWS = 10;
int ta4[TA4_ROWS][COLS] = {
    {7, 3, 4, 0, 6},
    {2, 7, 5, 5, 6},
    {1, 3, 7, 5, 6},
    {2, 3, 4, 7, 6},
    {2, 3, 4, 5, 7},
    {6, 0, 4, 5, 7},
    {1, 6, 0, 7, 6},
    {2, 3, 7, 5, 6},
    {5, 0, 4, 7, 6},
    {2, 3, 4, 5, 7}
};

namespace {
    void clearCollection(int collection[][COLS], int rows) {
        for (int r = 0; r < rows; ++r) {
            for (int c = 0; c < COLS; ++c) {
                collection[r][c] = 0;
            }
        }
    }

    int bestParentColumn(int arr[][COLS], int rNum, int cNum) {
        int bestValue = INT_MIN;
        int bestCol = cNum;

        for (int c = cNum - 1; c <= cNum + 1; ++c) {
            if (c >= 0 && c < COLS) {
                if (arr[rNum - 1][c] > bestValue) {
                    bestValue = arr[rNum - 1][c];
                    bestCol = c;
                }
            }
        }

        return bestCol;
    }

    void printTreasureMap(int treasure[][COLS], int rows) {
        cout << "Treasure map:" << endl;
        for (int r = 0; r < rows; ++r) {
            for (int c = 0; c < COLS; ++c) {
                cout << treasure[r][c] << '\t';
            }
            cout << endl;
        }
    }

    void printPath(int collection[][COLS], int rows) {
        cout << "Chosen path (X = selected cell):" << endl;
        for (int r = 0; r < rows; ++r) {
            for (int c = 0; c < COLS; ++c) {
                if (collection[r][c] == 1) {
                    cout << "X\t";
                } else {
                    cout << ".\t";
                }
            }
            cout << endl;
        }
    }

    int chosenTreasureSum(int treasure[][COLS], int collection[][COLS], int rows) {
        int sum = 0;
        for (int r = 0; r < rows; ++r) {
            for (int c = 0; c < COLS; ++c) {
                if (collection[r][c] == 1) {
                    sum += treasure[r][c];
                }
            }
        }
        return sum;
    }

    bool oneChosenCellPerRow(int collection[][COLS], int rows) {
        for (int r = 0; r < rows; ++r) {
            int count = 0;
            for (int c = 0; c < COLS; ++c) {
                if (collection[r][c] == 1) {
                    ++count;
                }
            }
            if (count != 1) {
                return false;
            }
        }
        return true;
    }

    bool validPathMoves(int collection[][COLS], int rows) {
        int previousCol = -1;

        for (int r = 0; r < rows; ++r) {
            int currentCol = -1;
            for (int c = 0; c < COLS; ++c) {
                if (collection[r][c] == 1) {
                    currentCol = c;
                    break;
                }
            }

            if (currentCol == -1) {
                return false;
            }

            if (r > 0) {
                int difference = currentCol - previousCol;
                if (difference < -1 || difference > 1) {
                    return false;
                }
            }

            previousCol = currentCol;
        }

        return true;
    }

    bool runSingleTest(const char* testName, int treasure[][COLS], int rows, int expected) {
        int (*collection)[COLS] = new int[rows][COLS];

        int result = maximumTreasure(treasure, collection, rows);
        bool correctValue = (result == expected);
        bool onePerRow = oneChosenCellPerRow(collection, rows);
        bool validMoves = validPathMoves(collection, rows);
        bool correctSum = (chosenTreasureSum(treasure, collection, rows) == result);

        bool passed = correctValue && onePerRow && validMoves && correctSum;

        cout << "[" << (passed ? "PASS" : "FAIL") << "] " << testName
             << " | Expected: " << expected
             << " | Got: " << result << endl;

        printTreasureMap(treasure, rows);
        printPath(collection, rows);
        cout << endl;

        delete[] collection;
        return passed;
    }
}

int maximumParent(int arr[][COLS], int rNum, int cNum) {
    int best = INT_MIN;

    for (int c = cNum - 1; c <= cNum + 1; ++c) {
        if (c >= 0 && c < COLS) {
            if (arr[rNum - 1][c] > best) {
                best = arr[rNum - 1][c];
            }
        }
    }

    return best;
}

int maximumTreasure(int treasure[][COLS], int collection[][COLS], int rows) {
    if (rows <= 0) {
        return 0;
    }

    clearCollection(collection, rows);

    int (*best)[COLS] = new int[rows][COLS];

    // Base case: first row is copied directly.
    for (int c = 0; c < COLS; ++c) {
        best[0][c] = treasure[0][c];
    }

    // Fill DP table.
    for (int r = 1; r < rows; ++r) {
        for (int c = 0; c < COLS; ++c) {
            best[r][c] = treasure[r][c] + maximumParent(best, r, c);
        }
    }

    // Find the best ending column in the last row.
    int bestTotal = best[rows - 1][0];
    int bestCol = 0;
    for (int c = 1; c < COLS; ++c) {
        if (best[rows - 1][c] > bestTotal) {
            bestTotal = best[rows - 1][c];
            bestCol = c;
        }
    }

    // Trace back the optimal path.
    int currentCol = bestCol;
    collection[rows - 1][currentCol] = 1;

    for (int r = rows - 1; r > 0; --r) {
        currentCol = bestParentColumn(best, r, currentCol);
        collection[r - 1][currentCol] = 1;
    }

    delete[] best;
    return bestTotal;
}

bool test_treasure_paths() {
    bool allPassed = true;

    // Assignment-provided tests
    allPassed = runSingleTest("ta1", ta1, TA1_ROWS, 7 * TA1_ROWS) && allPassed;
    allPassed = runSingleTest("ta2", ta2, TA2_ROWS, 7 * TA2_ROWS) && allPassed;
    allPassed = runSingleTest("ta3", ta3, TA3_ROWS, 7 * TA3_ROWS) && allPassed;
    allPassed = runSingleTest("ta4", ta4, TA4_ROWS, 7 * TA4_ROWS) && allPassed;

    // Extra edge-case tests for full marks
    int singleRow[1][COLS] = {
        {1, 9, 2, 0, 7}
    };
    allPassed = runSingleTest("single row", singleRow, 1, 9) && allPassed;

    int leftEdge[4][COLS] = {
        {7, 1, 1, 1, 1},
        {7, 1, 1, 1, 1},
        {7, 1, 1, 1, 1},
        {7, 1, 1, 1, 1}
    };
    allPassed = runSingleTest("left-edge path", leftEdge, 4, 28) && allPassed;

    int rightEdge[4][COLS] = {
        {1, 1, 1, 1, 7},
        {1, 1, 1, 1, 7},
        {1, 1, 1, 1, 7},
        {1, 1, 1, 1, 7}
    };
    allPassed = runSingleTest("right-edge path", rightEdge, 4, 28) && allPassed;

    int diagonalBest[3][COLS] = {
        {0, 50, 0, 0, 0},
        {0, 1, 60, 0, 0},
        {0, 0, 1, 70, 0}
    };
    allPassed = runSingleTest("diagonal best path", diagonalBest, 3, 180) && allPassed;

    int negativeValues[3][COLS] = {
        {-5, -1, -4, -3, -2},
        {-10, -1, -10, -1, -10},
        {-10, -10, 0, -10, -10}
    };
    allPassed = runSingleTest("negative values", negativeValues, 3, -2) && allPassed;

    return allPassed;
}
