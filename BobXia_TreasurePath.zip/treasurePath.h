#ifndef TREASUREPATH_H_INCLUDED
#define TREASUREPATH_H_INCLUDED

const int COLS = 5;

// Provided test maps
extern const int TA1_ROWS;
extern const int TA2_ROWS;
extern const int TA3_ROWS;
extern const int TA4_ROWS;

extern int ta1[][COLS];
extern int ta2[][COLS];
extern int ta3[][COLS];
extern int ta4[][COLS];

int maximumTreasure(int treasure[][COLS], int collection[][COLS], int rows);
/*
   Finds the maximum treasure path from any cell in the top row
   to any cell in the bottom row.

   Parameters:
     treasure[][COLS] - the treasure map (rows x COLS)
     collection[][COLS] - output array; marks cells on the optimal path with 1
     rows - number of rows in both arrays

   Returns: total value of the optimal path
*/

int maximumParent(int arr[][COLS], int rNum, int cNum);
/*
   Helper function: finds the maximum value from the possible
   parent cells (up-left, up, up-right) of cell [rNum][cNum].

   Parameters:
     arr[][COLS] - array of accumulated path values
     rNum - current row
     cNum - current column

   Returns: maximum value among valid parent cells
*/

bool test_treasure_paths();
/*
   Tests the treasure path algorithm with the provided test arrays
   and several edge cases.
   Returns true if all tests pass, false otherwise.
*/

#endif // TREASUREPATH_H_INCLUDED
