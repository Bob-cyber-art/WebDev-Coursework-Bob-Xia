#include <iostream>
#include "treasurePath.h"

using namespace std;

int main() {
    cout << "Running Treasure Path tests..." << endl << endl;

    if (test_treasure_paths()) {
        cout << endl << "All tests passed!" << endl;
    } else {
        cout << endl << "Some tests failed." << endl;
    }

    return 0;
}
