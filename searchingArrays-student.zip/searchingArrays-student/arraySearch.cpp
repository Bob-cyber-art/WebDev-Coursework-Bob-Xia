#include "arraySearch.h"

using namespace std;

// TODO: implement search_unsorted
// Loop through every element. Return true if value matches any element.
bool search_unsorted(int value, int arr[], int length) {
    return false; // replace this
}

// TODO: implement search_sorted
// Use binary search. Track firstIndex and lastIndex, compute midpoint each step.
bool search_sorted(int value, int arr[], int length) {
    return false; // replace this
}
